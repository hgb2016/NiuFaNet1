package com.dream.NiuFaNet.Bean;

/**
 * Created by Administrator on 2017/9/11 0011.
 */
public class ThirdInfoBeanWX {

    /**
     * userID : oRT6z0fCVY1gsuuNy-Y0NpqeVgu0
     * icon : http://wx.qlogo.cn/mmopen/vi_32/Iea4OyzU2fks70ficzqeauFPjPwhgrZFcAJZIGPhY7kQPWoShfYLicF48QOicMrg2Ln38RWqZB3ovWtFgans5RiaiaQ/0
     * token : HI2iPMYUS2VtCRx1jw_URC3MF13qaeycWgRfCEzK5FFc8_NVTeEma7t_MW2wUI5WfdTCwwj2J6UHo-Y9omT_oA
     * nickname : 条子
     * expiresIn : 7200
     * expiresTime : 1505112423608
     * unionid : oMoGHvyD3iILAFmPOw60Oiv_pp6U
     * province : Guizhou
     * gender : 0
     * openid : oRT6z0fCVY1gsuuNy-Y0NpqeVgu0
     * refresh_token : HI2iPMYUS2VtCRx1jw_UREa6ZFVhPs5z1QRtdc3K_DHuGs6-1GLyhqCURRoeV3bMBIpDiLZyE7fkSDZvXX9L8g
     * country : CN
     * city : Southwest Guizhou
     */

    private String userID;
    private String icon;
    private String token;
    private String nickname;
    private int expiresIn;
    private long expiresTime;
    private String unionid;
    private String province;
    private String gender;
    private String openid;
    private String refresh_token;
    private String country;
    private String city;

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public int getExpiresIn() {
        return expiresIn;
    }

    public void setExpiresIn(int expiresIn) {
        this.expiresIn = expiresIn;
    }

    public long getExpiresTime() {
        return expiresTime;
    }

    public void setExpiresTime(long expiresTime) {
        this.expiresTime = expiresTime;
    }

    public String getUnionid() {
        return unionid;
    }

    public void setUnionid(String unionid) {
        this.unionid = unionid;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getOpenid() {
        return openid;
    }

    public void setOpenid(String openid) {
        this.openid = openid;
    }

    public String getRefresh_token() {
        return refresh_token;
    }

    public void setRefresh_token(String refresh_token) {
        this.refresh_token = refresh_token;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }
}
