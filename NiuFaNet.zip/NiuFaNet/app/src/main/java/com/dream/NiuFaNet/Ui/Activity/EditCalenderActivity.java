package com.dream.NiuFaNet.Ui.Activity;

import com.dream.NiuFaNet.Base.CommonActivity;
import com.dream.NiuFaNet.R;

/**
 * Created by hou on 2018/3/31.
 */

public class EditCalenderActivity extends CommonActivity {
    @Override
    public int getLayoutId() {
        return R.layout.activity_editcalender;
    }

    @Override
    public void initView() {

    }

    @Override
    public void initDatas() {

    }

    @Override
    public void eventListener() {

    }

}
