package com.dream.NiuFaNet.Ui.Activity;

import com.dream.NiuFaNet.Base.CommonActivity;
import com.dream.NiuFaNet.R;

/**
 * 日程附件 展示
 * Created by hou on 2018/3/29.
 */

public class ApendixDetailActivity extends CommonActivity {
    @Override
    public int getLayoutId() {
        return R.layout.activity_apendixdetail;
    }

    @Override
    public void initView() {

    }

    @Override
    public void initDatas() {

    }

    @Override
    public void eventListener() {

    }
}
