package com.dream.NiuFaNet.Ui.Activity;

import com.dream.NiuFaNet.Base.CommonActivity;
import com.dream.NiuFaNet.R;

/**
 * 谁可见
 * Created by Administrator on 2018/4/4.
 */

public class WhoCanSeeActivity extends CommonActivity {
    @Override
    public int getLayoutId() {

        return R.layout.activity_whocansee;
    }

    @Override
    public void initView() {

    }

    @Override
    public void initDatas() {

    }

    @Override
    public void eventListener() {

    }


}
