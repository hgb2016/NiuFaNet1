package com.dream.NiuFaNet.Ui.Activity;

import com.dream.NiuFaNet.Base.CommonActivity;
import com.dream.NiuFaNet.Component.DaggerNFComponent;
import com.dream.NiuFaNet.R;

public class LawCalculateActivity extends CommonActivity {

    @Override
    public int getLayoutId() {
        return R.layout.activity_law_calculate;
    }

    @Override
    public void initView() {

    }

    @Override
    public void initDatas() {

    }

    @Override
    public void eventListener() {

    }
}
